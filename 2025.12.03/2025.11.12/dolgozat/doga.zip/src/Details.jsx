import React from 'react'

export default function Details() {
  return (
    <div class="form-check w-3 p-2 ">
        <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault"/>
        <label class="form-check-label" for="flexCheckDefault">Show</label>
        <input type="color" id="foreground" name="foreground" value="#e66465" />
  </div>
  )
}
