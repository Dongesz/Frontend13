import './App.css';
import Navbar from './Components/Navbar';
import Home from './Pages/Home';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Pizzak from './Pages/Pizzak';

function App() {
  return (
    <BrowserRouter>
      <div className='App'>
        <Navbar/>
          <Routes>
            <Route path='/' element={<Home/>}></Route>
            <Route path='/Pizzak' element={<Pizzak/>}></Route>
          </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;
