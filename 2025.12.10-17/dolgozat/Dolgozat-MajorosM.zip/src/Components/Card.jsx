import React from 'react'
export default function Card({name, image_url}) {
  return (
    <div class="card m-3" style={{width: "500px"}}>
        <img class="card-img-top img-fluid" style={{width: "500px", height: "500px"}} src={image_url}/>
        <div class="card-body">
            <h5 class="card-title">{name}</h5>
        </div>
    </div>
  )
}
